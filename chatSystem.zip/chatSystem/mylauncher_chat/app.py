import os
from datetime import datetime
from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy
from flask_socketio import SocketIO, join_room
from dotenv import load_dotenv

# ========================
# Configuração inicial
# ========================
load_dotenv()

app = Flask(__name__)

# Configurações vindas do .env
app.config['SECRET_KEY'] = os.getenv("SECRET_KEY", "fallback-secret")
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv("SQLALCHEMY_DATABASE_URI", "sqlite:///chat.db")
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
socketio = SocketIO(app)

# ========================
# Modelos de Banco
# ========================
class DM(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sender = db.Column(db.String(80), nullable=False)
    receiver = db.Column(db.String(80), nullable=False)
    content = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

# ========================
# Rotas
# ========================
@app.route("/")
def home():
    return "<h2>Servidor de chat ativo! Vá para /global_chat ou /dm/&lt;usuario&gt;</h2>"

@app.route("/global_chat")
def global_chat():
    # Aqui você deve substituir pelo usuário real da sessão/login
    user = os.getenv("TEST_USER", "Convidado")
    return render_template("global_chat.html", current_user={"username": user})

@app.route("/dm/<destino>")
def dm(destino):
    user = os.getenv("TEST_USER", "Convidado")
    # Pega histórico da conversa entre user e destino
    mensagens = DM.query.filter(
        ((DM.sender == user) & (DM.receiver == destino)) |
        ((DM.sender == destino) & (DM.receiver == user))
    ).order_by(DM.timestamp).all()
    return render_template("dm.html", destino=destino, mensagens=mensagens, current_user={"username": user})

# ========================
# Eventos SocketIO
# ========================
@socketio.on("join_global")
def handle_join_global(data):
    username = data["username"]
    join_room("global")
    socketio.emit(
        "new_global_message",
        {"user": "Sistema", "msg": f"{username} entrou no chat."},
        room="global"
    )

@socketio.on("send_global")
def handle_send_global(data):
    msg = data["msg"]
    username = data["user"]
    socketio.emit(
        "new_global_message",
        {"user": username, "msg": msg},
        room="global"
    )

@socketio.on("join_dm")
def handle_join_dm(data):
    username = data["username"]
    join_room(username)

@socketio.on("send_dm")
def handle_send_dm(data):
    sender = data["sender"]
    receiver = data["receiver"]
    msg = data["msg"]

    # Salva no banco
    dm = DM(sender=sender, receiver=receiver, content=msg)
    db.session.add(dm)
    db.session.commit()

    # Envia ao destinatário
    socketio.emit("receive_dm", {"sender": sender, "msg": msg}, room=receiver)

# ========================
# Main
# ========================
if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    socketio.run(app, debug=True)
